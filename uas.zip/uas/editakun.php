<?php
    include "dbaccess.php";
    $id_member = $_GET['id_member'];
    $sqledit = "SELECT * FROM identitas WHERE id_member = '$id_member'";
    $member = mysqli_query($kon, $sqledit);
    if(!$member){
        die("Gagal query identitas");
    };
    while($row = mysqli_fetch_assoc($member)){
        $usernameku = $row['username'];
        $naleng = $row['nama_lengkap'];
        $email = $row['email'];
        $telp = $row['telp'];
        $jekel = $row['jenis_kelamin'];
        if($row['photo'] != null){
            $photo = $row['photo'];
        }
        else{
            $photo = null;
        };
};
    $sqluser = "SELECT * FROM users WHERE username = '$usernameku'";
    $usersedit = mysqli_query($kon, $sqluser);
    if(!$usersedit){
        die("Gagal query users");
    };
    while($row2 = mysqli_fetch_assoc($usersedit)){
        $role = $row2['role'];
    }
?>
<title>EDIT AKUN - BERITAKU</title>
<script language="javascript">
        function roles(){
            alert("Role: Admin = akses semua | Editor = Tambah berita, wawasan dan iklan | Moderator = Moderasi akun dan wawasan | Pengiklan = pengiklanan dan wawasan | Analisis = Hanya Wawasan")
        }
    </script>
<center>
<h2>EDIT AKUN BERITAKU</h2>
Ubah data formulir akun anda dibawah ini:
<hr />
<form action="prosesedtakun.php" method="POST"> <!-- test -->
<table>
    	<tr>
            <td>Username</td><td>:</td><td><input type="text" value="<?php echo $usernameku; ?>" disabled/>
            <input hidden type="text" name="username" value="<?php echo $usernameku; ?>" readonly/>
        </td>
        </tr>
        <tr>
        	<td>Password Baru</td><td>:</td><td><input type="password" name="password"/></td>
        </tr>
        <tr>
        	<td>Password Baru Ulang</td><td>:</td><td><input type="password" name="password2"/></td>
        </tr>
        <tr>
        	<td>Role</td><td>:</td><td>
            <select name="role">
                <option value="admin" <?php if($role == 'admin') echo "selected"; ?>>Administrator</option>
                <option value="editor" <?php if($role == 'editor') echo "selected"; ?>>Editor</option>
                <option value="moderator" <?php if($role == 'moderator') echo "selected"; ?>>Moderator</option>
                <option value="pengiklan" <?php if($role == 'pengiklan') echo "selected"; ?>>Pengiklan</option>
                <option value="analisis" <?php if($role == 'analisis') echo "selected"; ?>>Analisis</option>
                <option value="member" <?php if($role == 'member') echo "selected"; ?>>Member</option>
            </select> 
            <a href="javascript:roles();">Bantuan</a>
            </td>
        </tr>
        <tr>
        	<td>Nama Lengkap</td><td>:</td><td><input type="text" name="nama_lengkap" value="<?php echo $naleng; ?>"/></td>
        </tr>
        <tr>
        	<td>E-mail</td><td>:</td><td><input type="text" name="email" value="<?php echo $email; ?>"/></td>
        </tr>
        <tr>
        	<td>Nomor Telepon</td><td>:</td><td><input type="text" name="telp" value="<?php echo $telp; ?>"/></td>
        </tr>
        <tr>
        	<td>Jenis Kelamin</td><td>:</td><td>
            <input type="radio" id="L" name="jenis_kelamin" value="L" <?php if($jekel == 'L') echo "checked"; ?>>
                <label for="L">Laki-laki</label>
            <input type="radio" id="P" name="jenis_kelamin" value="P" <?php if($jekel == 'P') echo "checked"; ?>>
                <label for="P">Perempuan</label>
            </td>
        </tr>
        <tr>
        	<td>URL foto (opsional)</td><td>:</td><td><input type="text" name="photo" value="<?php echo $photo; ?>"/></td>
        </tr>
        <tr>
            <td></td><td></td>
            <td>
                <b>Petunjuk:</b> Letakan gambar di dalam folder asset, <br />
                ketik nama file beserta formatnya.
            </td>
        </tr>
        <tr>
        	<td></td><td></td><td>
                <br />
                <input type="submit" name="simpan" value="Simpan"/>
                <input type="reset" name="reset" value="Reset"/>
            </td>
        </tr>
    </table>
</form>
<hr />
<button onClick="self.history.back();">Kembali ke halaman login</button><br /><br />
Copyright 2020 Rozi Vector.
</center>