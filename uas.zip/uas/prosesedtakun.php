<?php
    include "dbaccess.php";
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $role = $_POST['role'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $photo = $_POST['photo'];

    $dataValid = true;
    if(strlen(trim($username)) == 0){
        echo "<center>";
        echo "Username Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($password)) == 0){
                $newpassword="";
    }
    else{
                $newpassword="password = '$password', ";
    };
    if($password != $password2){
        echo "<center>";
        echo "Password tidak sama dengan password ulang! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    }
    if($role == "0") {
        echo "<center>";
        echo "Role Harus Dipilih! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($nama_lengkap)) == 0){
        echo "<center>";
        echo "Nama Lengkap Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($email)) == 0){
        echo "<center>";
        echo "E-mail Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($telp)) == 0){
        echo "<center>";
        echo "Nomor Telepon Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };

    if ($dataValid == false) {
        echo "<title>Kesalahan edit akun - BERITAKU</title>";
        echo "<center>";
        echo "<hr /><b>Masih Ada Kesalahan, silahkan perbaiki!</b> <hr />";
        echo "<input type='button' value='Kembali'
              onClick='self.history.back();' />";
        echo "</center>";
        exit;
    };

        //buat table users dan member di console phpMyAdmin
        $editakunSql = "UPDATE users SET $newpassword 
                          role = '$role' 
                          WHERE username = '$username'";
    mysqli_query($kon, $editakunSql) or 
    die("Gagal edit akun users!");
    //Primary key di $username
    $editidentitySql = "UPDATE identitas SET nama_lengkap = '$nama_lengkap',  
                          email = '$email',
                          telp = '$telp',
                          jenis_kelamin = '$jenis_kelamin',
                          photo = '$photo' 
                          WHERE username = '$username'";
    //akses Foreign key pada field username di console phpMyAdmin dengan sintaks:
    /* 
        ALTER TABLE member ADD FOREIGN KEY member_FKIndex1(username) REFERENCES users(username);
    */
    mysqli_query($kon, $editidentitySql) or die("Gagal edit akun member!");
    
    echo "<title>Akun Diedit - BERITAKU</title>";
    echo "<center>";
    echo "<hr />Akun sudah diedit!<br /> <br />";
    echo "</center>";
?>
<center>
<hr />
<button onClick="window.location.href = 'detailakun.php';">Kembali</button>
</center>