<?php

    include "dbaccess.php";
    mysqli_select_db($kon, "beritaku");
    $username = $_POST['username'];
    $password = $_POST['password'];
    $dataValid = true;
    if(strlen(trim($username)) == 0){
        echo "<center>";
        echo "Username Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    }
    if(strlen(trim($password)) == 0){
        echo "<center>";
        echo "Password Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    }
    else {
    $cek_db	= "SELECT * FROM users WHERE username='$username'";
	$query	= mysqli_query($kon, $cek_db);
		if(mysqli_num_rows($query) != 0){
			$row = mysqli_fetch_assoc($query);
			$db_user = $row['username'];
            $db_pass = $row['password'];
            $db_role = $row['role'];
            $db_block = $row['blokir'];
                if($username == $db_user && $password !== $db_pass){
                echo "<center>";
                echo "Password anda salah! <br /> <br />";
                echo "</center>";
                $dataValid = false;
                } 
                else if($db_block == 'ya'){
                echo "<center>";
                echo "Maaf, akun <b>$db_user</b> telah diblokir! Silahkan hubungi admin. <br /> <br />";
                echo "</center>";
                $dataValid = false;
                } 
         }
         else {
                echo "<center>";
                echo "Username tidak ditemukan! <br /> <br />";
                echo "</center>";
                $dataValid = false;
         }
    }
    if ($dataValid == false) {
        echo "<title>Kesalahan Login - BERITAKU</title>";
        echo "<center>";
        echo "<hr /><b>Gagal login, silahkan coba lagi!</b> <hr />";
        echo "<input type='button' value='Kembali'
              onClick='self.history.back();' />";
        echo "</center>";
        exit;
    };

    session_start(); //memulai sesi
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $db_role;
    $_SESSION['status'] = "online";
    $inactive = 600;
        if(isset($_SESSION['timeout']) ) {
            $session_life = time() - $_SESSION['start'];
            if($session_life > $inactive)
                { 
                    session_destroy();
                    echo "<title>Sesi Berakhir - BERITAKU</title>";
                    echo "Sesi Berakhir! Silahkan log in lagi. <br /><br />";
                    echo "<button onClick=\"window.location.href = 'index.html';\">Kembali ke halaman login</button>";
                }
        }
    $_SESSION['timeout'] = time();
    $useraktif = $_SESSION['username'];
    $roleaktif = $_SESSION['role'];
    header("location: beranda.php");
?>
