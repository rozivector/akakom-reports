<?php
    include "dbaccess.php";
    session_start();
    $useraktif = $_SESSION['username'];
    $roleaktif = $_SESSION['role'];
    $sql = "SELECT * FROM berita ORDER BY id_berita DESC";
    $berita = mysqli_query($kon, $sql);
    if(!$berita){
        die("Gagal query Berita");
    };
    $katberita = "SELECT * FROM kategori_berita ORDER BY id_kategoriberita ASC";
    $sqlkatberita = mysqli_query($kon, $katberita);
    if(!$sqlkatberita)
        die("Gagal query Kategori berita");
    while($katrow = mysqli_fetch_assoc($sqlkatberita)){
        $idKatRow[] = $katrow['id_kategoriberita'];
        $namaKatRow[] = $katrow['nama_kategoriberita'];
    }
?>
<title>Lihat Berita - BERITAKU</title>
<center>
<h2>Lihat Berita - BERITAKU</h2>
<hr />
<?php
    if($roleaktif == 'admin' || $roleaktif == 'editor'){
     echo "<button onclick=\"window.location.href = 'tambahberita.php';\">Tambah Berita</button> <br /><br />";
    }
?>
<table border="1">
    <tr>
    <th>No</th>
    <th>Gambar</th>
    <th>Judul dan Isi</th>
    <th>Rincian Berita</th>
    <?php
    if($roleaktif == 'admin' || $roleaktif == 'editor'){
        echo "<th>Aksi</th>";
    };
    ?>
    </tr>
    <?php
        $no = 1;
        while($row = mysqli_fetch_assoc($berita)){
            echo "<tr>";
            echo "<td>".$no."</td>";
            if($row['gambar'] == null || $row['gambar'] == ""){ //implementasi jika tidak ada gambar
                echo "<td></td>";
            }
            else{ //Selain itu, jika ada gambar, jalankan state ini
            echo "<td><a href='asset/".$row['gambar']."'><img src ='asset/".$row['gambar']."' width='100' /></a></td>";
            }
            echo "<td style='width:600px'><b>".$row['judul_berita']."</b> <br /> <br />".$row['isi_berita']."</td>";
            echo "<td>Penulis: <b>".$row['username']."</b> <br />";
            echo "Hari: ".$row['hari']."<br />";
            echo "Tanggal: ";
            $tanggal = DateTime::createFromFormat('Y-m-d', $row['tanggal_berita']);
            $formattgl = $tanggal->format('d-m-Y');
            echo $formattgl;
            echo "<br />";
            echo "Kategori berita: ";
            foreach($idKatRow as $index => $ulangKatRow){
                    if($idKatRow[$index] == $row['id_kategoriberita']){
                            echo $namaKatRow[$index];
                    }
            };
            echo "</td>";
            if($roleaktif == 'admin' || $roleaktif == 'editor'){
            echo "<td align='center' width='100'>";
            echo "<button onClick=\"window.location.href = 'editberita.php?id_berita=".$row['id_berita']."';\">Edit</button><br /><br /><button onClick=\"window.location.href = 'hapusberita.php?id_berita=".$row['id_berita']."';\">Hapus</button>";
            echo "</td>";
            };
            echo "</tr>";
            $no++;
        }
    ?>
</table><br />
<hr />
<button onClick="window.location.href = 'beranda.php';">Kembali ke beranda</button><br /><br />
Copyright 2020 Rozi Vector.
</center>