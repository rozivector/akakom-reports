-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2020 at 04:38 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `beritaku`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `idalbum` int(11) NOT NULL,
  `namaalb` varchar(50) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `id_kategoriberita` int(11) NOT NULL,
  `judul_berita` varchar(60) NOT NULL,
  `isi_berita` text NOT NULL,
  `hari` varchar(15) NOT NULL,
  `tanggal_berita` date NOT NULL,
  `gambar` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id_berita`, `username`, `id_kategoriberita`, `judul_berita`, `isi_berita`, `hari`, `tanggal_berita`, `gambar`) VALUES
(1, 'rozivector', 1, 'Gempa Bumi Jogja', 'Terjadi gempa bumi di daerah Bantul, Jogjakarta pada malam hari jam 7 malam dengan scala 5.4 SR', 'Sunday', '2020-04-05', 'gempa.jpg'),
(4, 'rozivector', 2, 'Manfaat Internet Positif', 'Internet merupakan kebutuhan kita sehari-hari. Namun terjadi tindakan yang melanggar hukum sosial. Untuk itu, diperlukan sebuah pencegahan. Pemerintah menggunakan internet positif supaya dapat melindungi masyarakat untuk mengakses ke internet.', 'Sunday', '2020-04-05', ''),
(5, 'telogoreng', 5, 'Corona Bercanda lagi', 'Baru-baru ini viral terjadi krisis global yaitu infeksi corona virus di berbagai belahan dunia. Virus ini dapat menyebar cepat melalui udara dan juga zat padat lain.', 'Sunday', '2020-04-05', '');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE `galeri` (
  `idgaleri` int(11) NOT NULL,
  `gambar` varchar(40) DEFAULT NULL,
  `url` varchar(50) NOT NULL,
  `idalbum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `identitas`
--

CREATE TABLE `identitas` (
  `id_member` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telp` bigint(20) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `photo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `identitas`
--

INSERT INTO `identitas` (`id_member`, `username`, `nama_lengkap`, `email`, `telp`, `jenis_kelamin`, `photo`) VALUES
(6, 'rozivector', 'Rozi Vector', 'rozi.qood16@gmail.com', 5111000, 'L', 'image.png'),
(7, 'telogoreng', 'Telo Goreng', 'telo@mail.com', 112423, 'P', 'image2.png'),
(11, 'martabak', 'Martabak Manis', 'martabak@mail.com', 527942, 'L', ''),
(12, 'iklan', 'Pak Bambang', 'mailku@mail.com', 114053, 'P', ''),
(13, 'bintang', 'Si kecil', 'kecil@mailnya.com', 774392, 'L', ''),
(14, 'bakwan', 'Bakwan Goreng', 'bakwan@mailku.com', 812934, 'P', ''),
(15, 'keblock', 'Segaran', 'se@mailku.com', 99032, 'P', '');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_berita`
--

CREATE TABLE `kategori_berita` (
  `id_kategoriberita` int(11) NOT NULL,
  `nama_kategoriberita` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori_berita`
--

INSERT INTO `kategori_berita` (`id_kategoriberita`, `nama_kategoriberita`) VALUES
(1, 'Bencana Alam'),
(2, 'Sosial Media'),
(3, 'Politik'),
(4, 'Keuangan'),
(5, 'Kesehatan'),
(6, 'Pendidikan'),
(7, 'Gaya Hidup'),
(9, 'Finansial'),
(12, 'makanan'),
(14, 'minuman');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` varchar(40) NOT NULL,
  `blokir` enum('ya','tidak') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `role`, `blokir`) VALUES
('bakwan', 'bakwan', 'member', 'tidak'),
('bintang', 'bintang', 'analisis', 'tidak'),
('iklan', 'iklan', 'pengiklan', 'tidak'),
('keblock', 'keblock', 'member', 'ya'),
('martabak', 'galau', 'moderator', 'tidak'),
('rozivector', 'mantabs', 'admin', 'tidak'),
('telogoreng', 'telogoreng', 'editor', 'tidak');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`idalbum`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`),
  ADD KEY `berita_FKIndex2` (`id_kategoriberita`) USING BTREE,
  ADD KEY `berita_FKIndex1` (`username`) USING BTREE;

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`idgaleri`),
  ADD KEY `idgaleri_idalbum` (`idalbum`) USING BTREE;

--
-- Indexes for table `identitas`
--
ALTER TABLE `identitas`
  ADD PRIMARY KEY (`id_member`),
  ADD KEY `member_FKIndex1` (`username`) USING BTREE;

--
-- Indexes for table `kategori_berita`
--
ALTER TABLE `kategori_berita`
  ADD PRIMARY KEY (`id_kategoriberita`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `idalbum` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id_berita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
  MODIFY `idgaleri` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `identitas`
--
ALTER TABLE `identitas`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `kategori_berita`
--
ALTER TABLE `kategori_berita`
  MODIFY `id_kategoriberita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `berita`
--
ALTER TABLE `berita`
  ADD CONSTRAINT `berita_FKIndex1` FOREIGN KEY (`username`) REFERENCES `users` (`username`),
  ADD CONSTRAINT `berita_FKIndex2` FOREIGN KEY (`id_kategoriberita`) REFERENCES `kategori_berita` (`id_kategoriberita`);

--
-- Constraints for table `galeri`
--
ALTER TABLE `galeri`
  ADD CONSTRAINT `galeri_ibfk_1` FOREIGN KEY (`idalbum`) REFERENCES `album` (`idalbum`);

--
-- Constraints for table `identitas`
--
ALTER TABLE `identitas`
  ADD CONSTRAINT `member_FKIndex1` FOREIGN KEY (`username`) REFERENCES `users` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
