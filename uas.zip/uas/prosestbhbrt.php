<?php
    include "dbaccess.php";
    session_start();
    $judulBerita = $_POST['judul_berita'];
    $kategoriBerita = $_POST['id_kategoriberita'];
    $penulis = $_SESSION['username']; //karena bersifat default, maka tidak memerlukan metode POST
    $hari = date("l"); 
    //karena tanggal POST tidak bisa apply di SQL, kita menggunakan state CURRENT_DATE di command
    $isiBerita = $_POST['isi_berita'];
    $gambar = $_POST['gambar'];

    $dataValid = true;
    if(strlen(trim($judulBerita)) == 0){
        echo "<center>";
        echo "Judul Berita Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if($kategoriBerita == 0){
        echo "<center>";
        echo "Kategori Berita Harus Dipilih! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if($penulis == "0") {
        echo "<center>";
        echo "Penulis harus diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($hari)) == 0){
        echo "<center>";
        echo "Hari Berita Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($isiBerita)) == 0){
        echo "<center>";
        echo "Isi Berita Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };

    if ($dataValid == false) {
        echo "<title>Kesalahan buat berita - BERITAKU</title>";
        echo "<center>";
        echo "<hr /><b>Masih Ada Kesalahan, silahkan perbaiki!</b> <hr />";
        echo "<input type='button' value='Kembali'
              onClick='self.history.back();' />";
        echo "</center>";
        exit;
    };

        //buat table users dan identitas di console phpMyAdmin
    $beritaSql = "INSERT INTO berita
            (username, id_kategoriberita, judul_berita, isi_berita, hari, 
            tanggal_berita, gambar)
            values
            ('$penulis', '$kategoriBerita', '$judulBerita', '$isiBerita', '$hari', 
            CURRENT_DATE, '$gambar'); ";
    mysqli_query($kon, $beritaSql) or 
    die("Gagal buat berita baru!");
    
    echo "<title>Berita ditambahkan - BERITAKU</title>";
    echo "<center>";
    echo "<hr />Selamat, berita anda telah dikirim!<br /> <br />";
    echo "</center>";
?>
<center>
<hr />
<button onClick="window.location.href = 'lihatberita.php';">Lihat Berita</button>
<button onClick="window.location.href = 'beranda.php';">Kembali ke beranda</button>
</center>