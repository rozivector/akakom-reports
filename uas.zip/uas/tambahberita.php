<?php
    include "dbaccess.php";
    session_start();
    $penulis = $_SESSION['username'];
?>
<title>Berita Baru - BERITAKU</title>
<center>
<h2>BUAT BERITA BARU</h2>
Isi formulir berita dibawah ini:
<hr />
<form action="prosestbhbrt.php" method="POST"> <!-- test -->
<table>
    	<tr>
        	<td>Judul Berita</td><td>:</td><td><input type="text" name="judul_berita"/></td>
        </tr>
        <tr>
        	<td>Kategori Berita</td><td>:</td><td>
            <select name="id_kategoriberita">
                <option value="0" selected>----PILIH----</option>
                <option value="1">Bencana Alam</option>
                <option value="2">Sosial Media</option>
                <option value="3">Politik</option>
                <option value="4">Keuangan</option>
                <option value="5">Kesehatan</option>
                <option value="6">Pendidikan</option>
            </select> 
            </td>
        </tr>
        <tr>
            <td>Penulis</td><td>:</td><td><input type="text" value="<?php echo "$penulis"; ?>" disabled />
            <input hidden type="text" name="username" value="<?php echo "$penulis"; ?>" readonly /></td>
        </tr>
        <tr>
            <td>Hari</td><td>:</td><td><input type="text" value="<?php echo date("l"); ?>" disabled />
            <input hidden type="text" name="hari" value="<?php echo date("l"); ?>" readonly /></td>
        </tr>
        <tr>
            <td>Tanggal (hh-bb-tttt)</td><td>:</td><td><input type="text" value="<?php echo date("d-m-Y"); ?>" disabled />
            <input hidden type="text" name="hari" value="<?php echo date("d-m-Y"); ?>" readonly /></td>
        </tr>
        <tr>
        	<td>Isi Berita</td><td>:</td><td><textarea name="isi_berita" rows="4" cols="50"></textarea></td>
        </tr>
        <tr>
            <td>URL gambar (opsional)</td><td>:</td>
            <td>
                <input type="text" name="gambar"/>
            </td>
        </tr>
        <tr>
            <td></td><td></td>
            <td>
                <b>Petunjuk:</b> Letakan gambar di dalam folder asset, <br />
                ketik nama file beserta formatnya.
            </td>
        </tr>
        <tr>
        	<td></td><td></td><td>
                <br />
                <input type="submit" name="tambah" value="Tambah"/>
                <input type="reset" name="reset" value="Reset"/>
            </td>
        </tr>
    </table>
</form>
<hr />
<button onClick="self.history.back();" name="batal">Batal</button><br />
<br />
Copyright 2020 Rozi Vector.
</center>
