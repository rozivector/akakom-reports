<?php
    include "dbaccess.php";
    $judulBerita = $_POST['judul_berita'];
    $kategoriBerita = $_POST['id_kategoriberita'];
    $penulis = $_POST['username']; //karena bersifat default, maka tidak memerlukan metode POST
    //karena tanggal POST tidak bisa apply di SQL, kita menggunakan state CURRENT_DATE di command
    $isiBerita = $_POST['isi_berita'];
    $gambar = $_POST['gambar'];
    $idberita = $_POST['id_berita'];

    $dataValid = true;
    if(strlen(trim($judulBerita)) == 0){
        echo "<center>";
        echo "Judul Berita Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if($kategoriBerita == 0){
        echo "<center>";
        echo "Kategori Berita Harus Dipilih! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if($penulis == "0") {
        echo "<center>";
        echo "Penulis harus diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($isiBerita)) == 0){
        echo "<center>";
        echo "Isi Berita Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };

    if ($dataValid == false) {
        echo "<title>Kesalahan edit berita - BERITAKU</title>";
        echo "<center>";
        echo "<hr /><b>Masih Ada Kesalahan, silahkan perbaiki!</b> <hr />";
        echo "<input type='button' value='Kembali'
              onClick='self.history.back();' />";
        echo "</center>";
        exit;
    };

        //buat table users dan identitas di console phpMyAdmin
        $editberitaSql = "UPDATE berita SET judul_berita = '$judulBerita', 
                          id_kategoriberita = '$kategoriBerita', 
                          isi_berita = '$isiBerita', 
                          gambar = '$gambar'
                          WHERE id_berita = '$idberita'";
    mysqli_query($kon, $editberitaSql) or 
    die("Gagal edit berita!");
    
    echo "<title>Berita diedit - BERITAKU</title>";
    echo "<center>";
    echo "<hr />Selamat, berita anda telah diedit!<br /> <br />";
    echo "</center>";
?>
<center>
<hr />
<button onClick="window.location.href = 'lihatberita.php';">Lihat Berita</button>
</center>
