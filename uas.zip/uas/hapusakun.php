<?php
    include "dbaccess.php";
    $id_member = $_GET['id_member'];
    $sqledit = "SELECT * FROM identitas WHERE id_member=$id_member;";
    $member = mysqli_query($kon, $sqledit);
    if(!$member){
        die("Gagal query identitas");
    };
    while($row = mysqli_fetch_assoc($member)){
        $usernameku = $row['username'];
    };
    $hapus = "DELETE FROM identitas WHERE id_member = $id_member; ";
    mysqli_query($kon, $hapus) or 
    die("Gagal menghapus akun! Error proses: identitas");
    $hapus2 = "DELETE FROM users WHERE username='$usernameku'; ";
    mysqli_query($kon, $hapus2) or 
    die("Gagal menghapus akun! Error proses: users");
    echo "<script>
        alert('Akun berhasil dihapus! ^_^ Anda telah logout');
        document.location.href= 'logout.php';
        </script>";
?>