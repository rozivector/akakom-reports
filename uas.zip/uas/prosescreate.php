<?php
    include "dbaccess.php";
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    $role = $_POST['role'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $email = $_POST['email'];
    $telp = $_POST['telp'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $photo = $_POST['photo'];

    $dataValid = true;
    if(strlen(trim($username)) == 0){
        echo "<center>";
        echo "Username Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($password)) == 0){
        echo "<center>";
        echo "Password Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if($password != $password2){
        echo "<center>";
        echo "Password tidak sama dengan password ulang! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    }
    if($role == "0") {
        echo "<center>";
        echo "Role Harus Dipilih! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($nama_lengkap)) == 0){
        echo "<center>";
        echo "Nama Lengkap Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($email)) == 0){
        echo "<center>";
        echo "E-mail Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };
    if(strlen(trim($telp)) == 0){
        echo "<center>";
        echo "Nomor Telepon Harus Diisi! <br /> <br />";
        echo "</center>";
        $dataValid = false;
    };

    if ($dataValid == false) {
        echo "<title>Kesalahan buat akun - BERITAKU</title>";
        echo "<center>";
        echo "<hr /><b>Masih Ada Kesalahan, silahkan perbaiki!</b> <hr />";
        echo "<input type='button' value='Kembali'
              onClick='self.history.back();' />";
        echo "</center>";
        exit;
    };

        //buat table users dan member di console phpMyAdmin
    $usersql = "INSERT INTO users
            (username, password, role, blokir)
            values
            ('$username', '$password', '$role', 'tidak') ";
    mysqli_query($kon, $usersql) or 
    die("Gagal buat akun users!");
    //Primary key di $username
    $membersql = "INSERT INTO identitas(
                username, nama_lengkap, email, telp, jenis_kelamin, photo)
                values ('$username', '$nama_lengkap', '$email', '$telp', '$jenis_kelamin'
                , '$photo')";
    //akses Foreign key pada field username di console phpMyAdmin dengan sintaks:
    /* 
        ALTER TABLE member ADD FOREIGN KEY member_FKIndex1(username) REFERENCES users(username);
    */
    mysqli_query($kon, $membersql) or die("Gagal buat akun member!");
    
    echo "<title>Akun Dibuat - BERITAKU</title>";
    echo "<center>";
    echo "<hr />Akun sudah dibuat, harap ingat akun ini!<br /> <br />";
    echo "Username : $username <br />";
    echo "Password : $password <br />";
    echo "Role     : $role <br />";
    echo "</center>";
?>
<center>
<hr />
<button onClick="window.location.href = 'index.html';">Kembali ke halaman login</button>
</center>