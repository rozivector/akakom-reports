<?php
    include "dbaccess.php";
    session_start();
    $id_berita = $_GET['id_berita'];
    $sqledit = "SELECT * FROM berita WHERE id_berita = $id_berita";
    $berita = mysqli_query($kon, $sqledit);
    if(!$berita){
        die("Gagal query Berita");
    };
    while($row = mysqli_fetch_assoc($berita)){
            $judul = $row['judul_berita'];
            $kat = $row['id_kategoriberita'];
            $penulis = $row['username'];
            $tanggal = DateTime::createFromFormat('Y-m-d', $row['tanggal_berita']);
            $formattgl = $tanggal->format('d-m-Y');
            $hari = $row['hari'];
            $isiberita = $row['isi_berita'];
            if($row['gambar'] != null){
                $gambar = $row['gambar'];
            }
            else{
                $gambar = null;
            };
    };
?>
<title>EDIT Berita - BERITAKU</title>
<center>
<h2>EDIT BERITA</h2>
Ubah isi formulir berita dibawah ini:
<hr />
<form action="prosesedtbrt.php" method="POST"> <!-- test -->
<table>
            <input hidden type="text" name="id_berita" value="<?php echo $id_berita; ?>" readonly/>
    	<tr>
        	<td>Judul Berita</td><td>:</td><td><input type="text" name="judul_berita" value="<?php echo $judul; ?>"/></td>
        </tr>
        <tr>
        	<td>Kategori Berita</td><td>:</td><td>
            <select name="id_kategoriberita">
                <option value="1" <?php if($kat == '1') echo "selected"; ?>>Bencana Alam</option>
                <option value="2" <?php if($kat == '2') echo "selected"; ?>>Sosial Media</option>
                <option value="3" <?php if($kat == '3') echo "selected"; ?>>Politik</option>
                <option value="4" <?php if($kat == '4') echo "selected"; ?>>Keuangan</option>
                <option value="5" <?php if($kat == '5') echo "selected"; ?>>Kesehatan</option>
                <option value="6" <?php if($kat == '6') echo "selected"; ?>>Pendidikan</option>
            </select> 
            </td>
        </tr>
        <tr>
            <td>Penulis</td><td>:</td><td><input type="text" value="<?php echo $penulis; ?>" disabled />
            <input hidden type="text" name="username" value="<?php echo $penulis; ?>" readonly />
            </td>
        </tr>
        <tr>
            <td>Hari</td><td>:</td><td><input type="text" value="<?php echo $hari; ?>" disabled />
            <input hidden type="text" name="hari" value="<?php echo $hari; ?>" readonly />
        </td>
        </tr>
        <tr>
            <td>Tanggal (hh-bb-tttt)</td><td>:</td><td><input type="text" value="<?php echo $formattgl; ?>" disabled/>
            <input hidden type="text" name="hari" value="<?php echo $formattgl; ?>" readonly/>
        </td>
        </tr>
        <tr>
        	<td>Isi Berita</td><td>:</td><td><textarea name="isi_berita" rows="4" cols="50"><?php echo $isiberita; ?></textarea></td>
        </tr>
        <tr>
            <td>URL gambar (opsional)</td><td>:</td>
            <td>
                <input type="text" name="gambar" value="<?php echo $gambar; ?>"/>
            </td>
        </tr>
        <tr>
            <td></td><td></td>
            <td>
                <b>Petunjuk:</b> Letakan gambar di dalam folder asset, <br />
                ketik nama file beserta formatnya.
            </td>
        </tr>
        <tr>
        	<td></td><td></td><td>
                <br />
                <input type="submit" name="simpan" value="Simpan"/>
                <input type="reset" name="reset" value="Reset"/>
            </td>
        </tr>
    </table>
</form>
<hr />
<button onClick="self.history.back();" name="batal">Batal</button><br />
<br />
Copyright 2020 Rozi Vector.
</center>
