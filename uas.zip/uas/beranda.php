<?php
    include "dbaccess.php";
    session_start();
    $useraktif = $_SESSION['username'];
    $roleaktif = $_SESSION['role'];
?>
<!DOCTYPE html>
<title>Beranda - BERITAKU</title>
<body>
<script language="javascript">
        function iklan(){
            alert("Anda mempunyai izin pengiklanan, akses role: admin, editor dan pengiklan")
        }
        function moderate(){
            alert("Anda mempunyai izin moderasi akun, akses role: admin dan moderator")
        }
        function wawasan(){
            alert("Anda mempunyai izin lihat wawasan, akses role: admin, editor, moderator, pengiklan dan analisis")
        }
    </script>
<center>
        <?php
        echo "<h1>Selamat Datang di BERITAKU, $useraktif!</h1>";
        echo "<b>".date("l")."</b>, ".date("d-m-Y")."<br /><br />";
        echo "Role anda : $roleaktif "; 
        ?>
    <br />
    <hr />
    <button onclick="window.location.href = 'lihatberita.php';">Lihat Berita</button> <br /><br />
    <?php
    if($roleaktif == 'admin' || $roleaktif == 'editor'){
     echo "<button onclick=\"window.location.href = 'tambahberita.php';\">Tambah Berita</button> <br /><br />";
    }
    ?>
    <?php
    if($roleaktif == 'admin' || $roleaktif == 'editor' || $roleaktif == 'pengiklan'){
    echo "<button onclick=\"iklan()\">Pengiklanan</button> <br /><br />";
    }
    ?>
    <?php
    if($roleaktif != 'member'){
    echo "<button onclick=\"wawasan()\">Lihat Wawasan</button> <br /><br />";
    }
    ?>
    <?php
    if($roleaktif == 'admin' || $roleaktif == 'moderator'){
    echo "<button onclick=\"moderate()\">Moderasi Akun</button> <br /><br />";
    }
    ?>
    <button onclick="window.location.href = 'detailakun.php';">Informasi Akun</button> <br /><br />
    <button onClick="window.location.href = 'logout.php';">Log Out</button>
    <hr />
    Copyright 2020 Rozi Vector.
</center>
</body>
</html>

