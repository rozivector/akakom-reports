<?php
    include "dbaccess.php";
    $id = $_GET['id_berita'];
    $hapus = "DELETE FROM berita WHERE id_berita = $id ";
    mysqli_query($kon, $hapus) or 
    die("Gagal menghapus berita!");
    echo "<script>
        alert('Berita berhasil dihapus! ^_^');
        document.location.href= 'lihatberita.php';
        </script>";
?>