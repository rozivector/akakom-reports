<?php
    include "dbaccess.php";
    session_start();
    $username = $_SESSION['username'];
    $userstatus = $_SESSION['status'] or $userstatus = "offline";
    $cek_user	= "SELECT * FROM users WHERE username='$username'";
	$query	= mysqli_query($kon, $cek_user);
		if(mysqli_num_rows($query) != 0){
			$row = mysqli_fetch_assoc($query);
            $db_user = $row['username'];
            $db_pass = $row['password'];
            $db_role = $row['role'];
        };
    $cek_identitas = "SELECT * FROM identitas WHERE username='$username'";
    $query2	= mysqli_query($kon, $cek_identitas);
		if(mysqli_num_rows($query2) != 0){
			$row = mysqli_fetch_assoc($query2);
            $db_user = $row['username'];
            $db_idmember = $row['id_member'];
            $db_namalengkap = $row['nama_lengkap'];
            $db_email = $row['email'];
            $db_telp = $row['telp'];
            $db_jenkel = $row['jenis_kelamin'];
            $db_photo = $row['photo'];
        };
    $db_jenkel = 'L' ? $parse_jenkel = "Laki-laki" : $parse_jenkel = "Perempuan";
?>
<title>Informasi akun - BERITAKU</title>
<center>
    <h2>Informasi akun BERITAKU anda</h2>
    <hr />
<table>
    <tr>
        <td><b>ID</b></td><td>:</td><td><?php echo "$db_idmember"; ?></td>
    </tr>
    <tr>
        <td><b>Username</b></td><td>:</td><td><?php echo "$db_user"; ?></td>
    </tr>
    <tr>
        <td><b>Status</b></td><td>:</td><td><?php echo "$userstatus"; ?></td>
    </tr>
    <tr>
        <td><b>Password</b></td><td>:</td><td><?php echo "$db_pass"; ?></td>
    </tr>
    <tr>
        <td><b>Role</b></td><td>:</td><td><?php echo "$db_role"; ?></td>
    </tr>
    <tr>
        <td><br /></td>
    </tr>
    <tr>
        <td><b>Nama Lengkap</b></td><td>:</td><td><?php echo "$db_namalengkap"; ?></td>
    </tr>
    <tr>
        <td><b>Jenis Kelamin</b></td><td>:</td><td><?php echo "$parse_jenkel"; ?></td>
    </tr>
    <tr>
        <td><b>Email</b></td><td>:</td><td><?php echo "$db_email"; ?></td>
    </tr>
    <tr>
        <td><b>No. Telepon</b></td><td>:</td><td><?php echo "$db_telp"; ?></td>
    </tr>
    <tr>
        <td><b>URL Foto</b></td><td>:</td><td>
            <?php 
            if(!$db_photo || $db_photo == null || $db_photo == ""){ 
                echo "-";
            } 
            else {
                echo "<a href='asset/".$db_photo."'>";
                echo "<img src='asset/".$db_photo."' width='100px'/>";
                echo "</a>";
            };
            ?> <!-- Jika tidak ada foto muncul "-"-->
        </td>
    </tr>
</table>
<hr />
<button onClick="window.location.href = 'editakun.php?id_member=<?php echo "$db_idmember"; ?>';">Edit Akun</button> &nbsp; &nbsp;
<button onClick="window.location.href = 'hapusakun.php?id_member=<?php echo "$db_idmember"; ?>';">Hapus Akun</button><br /> <br />
<button onClick="window.location.href = 'beranda.php';">Kembali ke beranda</button><br /><br />
Copyright 2020 Rozi Vector.
</center>